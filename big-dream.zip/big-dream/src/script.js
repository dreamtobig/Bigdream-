// Add interactivity here, e.g., a responsive navbar toggle
document.addEventListener("DOMContentLoaded", () => {
  console.log("BIG DREAM Website Ready");
});